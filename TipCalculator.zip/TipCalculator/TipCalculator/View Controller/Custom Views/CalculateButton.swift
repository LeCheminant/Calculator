//
//  CalculateButton.swift
//  TipCalculator
//
//  Created by Jacob LeCheminant on 2/10/20.
//  Copyright © 2020 Jacob LeCheminant. All rights reserved.
//

import UIKit

class CalculateButton: UIButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpViews()
    }
    
    func setUpViews() {
        addAccentBorder()
        changeTextTintColor(color: .systemBlue)
    }
    
    func addAccentBorder(width: CGFloat = 1, color: UIColor = .systemBlue) {
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
        self.layer.cornerRadius = 15
    }
    
    func changeTextTintColor(color: UIColor) {
        self.tintColor = color
    }
}
