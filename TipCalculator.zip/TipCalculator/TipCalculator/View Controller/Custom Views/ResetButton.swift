//
//  ResetButton.swift
//  TipCalculator
//
//  Created by Jacob LeCheminant on 2/10/20.
//  Copyright © 2020 Jacob LeCheminant. All rights reserved.
//

import UIKit

class ResetButton: UIButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpViews()
    }
    
    func setUpViews() {
        addAccentBorder()
        changeTextTintColor(color: .red)
    }
    
    func addAccentBorder(width: CGFloat = 1, color: UIColor = .red) {
        self.layer.borderWidth = width
        self.layer.borderColor = color.cgColor
        self.layer.cornerRadius = 15
    }
    
    func changeTextTintColor(color: UIColor) {
        self.tintColor = color
    }
}
