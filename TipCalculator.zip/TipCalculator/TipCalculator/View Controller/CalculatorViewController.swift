//
//  CalculatorViewController.swift
//  TipCalculator
//
//  Created by Jacob LeCheminant on 2/10/20.
//  Copyright © 2020 Jacob LeCheminant. All rights reserved.
//

import UIKit

class CalculatorViewController: UIViewController {

    @IBOutlet weak var receiptTotalLabel: UILabel!
    @IBOutlet weak var receiptTotalTextField: UITextField!
    @IBOutlet weak var receiptPercentageLabel: UILabel!
    @IBOutlet weak var receiptPercentageSlider: UISegmentedControl!
    @IBOutlet weak var calculateButton: CalculateButton!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var tipAmountVALUELabel: UILabel!
    @IBOutlet weak var newTotalLabel: UILabel!
    @IBOutlet weak var newTotalVALUELabel: UILabel!
    @IBOutlet weak var resetButton: ResetButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        receiptTotalTextField.text = ""
        tipAmountVALUELabel.text = "$0.00"
        newTotalVALUELabel.text = "$0.00"
        setUpViews()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculateButtonTapped(_ sender: Any) {
        guard let receiptAmountText = receiptTotalTextField.text,
            let receiptAmount = Double(receiptAmountText) else {return}
        calculateTip(tip: receiptAmount)
        receiptTotalTextField.resignFirstResponder()
        tipAmountVALUELabel.isHighlighted = true
        tipAmountVALUELabel.highlightedTextColor = .systemOrange
    }
    
    @IBAction func resetButtonTapped(_ sender: Any) {
        receiptTotalTextField.text = ""
        tipAmountVALUELabel.text = "$0.00"
        newTotalVALUELabel.text = "$0.00"
        receiptPercentageSlider.selectedSegmentIndex = 0
        tipAmountVALUELabel.isHighlighted = false
    }
    
    func setUpViews() {
//        resetButton.tintColor = .systemRed
//        calculateButton.tintColor = .systemGreen
        receiptPercentageSlider.selectedSegmentTintColor = .systemGreen
        newTotalVALUELabel.textColor = .gray
        
    }
    
    func calculateTip(tip: Double) {
        guard let receiptTotalText = receiptTotalTextField.text,
            let receiptTotal = Double(receiptTotalText) else {return}
        newTotalVALUELabel.text = receiptTotalText
        if receiptPercentageSlider.selectedSegmentIndex == 0 {
            let tipAmount = receiptTotal * 0.15
            let newTotal = tipAmount + receiptTotal
            tipAmountVALUELabel.text = String("$\(tipAmount)")
            newTotalVALUELabel.text = String("$\(newTotal)")
        } else if receiptPercentageSlider.selectedSegmentIndex == 1 {
            let tipAmount = receiptTotal * 0.18
            let newTotal = tipAmount + receiptTotal
            tipAmountVALUELabel.text = String("$\(tipAmount)")
            newTotalVALUELabel.text = String("$\(newTotal)")
        } else {
            let tipAmount = receiptTotal * 0.20
            let newTotal = tipAmount + receiptTotal
            tipAmountVALUELabel.text = String("$\(tipAmount)")
            newTotalVALUELabel.text = String("$\(newTotal)")
        }
    }

}
